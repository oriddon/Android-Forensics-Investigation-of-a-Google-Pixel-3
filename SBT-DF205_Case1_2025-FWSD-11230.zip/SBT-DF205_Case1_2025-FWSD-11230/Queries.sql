-- SBT-DF205-C1
-- Android Forensics Case 1
-- SQL queries used during forensic examination

-- ==========================================================
-- TASK 2: DEVICE IDENTITY AND PROFILES
-- Database: data/system_de/0/accounts_de.db
-- Purpose: Identify account associations for Android User 0
-- ==========================================================

PRAGMA table_info(accounts);

SELECT _id, name, type, previous_name
FROM accounts;


-- ==========================================================
-- Database: data/system_de/11/accounts_de.db
-- Purpose: Identify account associations for Android User 11
-- ==========================================================

PRAGMA table_info(accounts);

SELECT _id, name, type, previous_name
FROM accounts;


-- ==========================================================
-- Database: data/system_ce/0/accounts_ce.db
-- Purpose: Examine available schema without exposing secrets
-- Result: No accounts table/schema returned during examination
-- ==========================================================

PRAGMA table_info(accounts);

-- ==========================================================
-- TASK 4: AOSP SMS / MMS
-- Database:
-- data/data/com.android.providers.telephony/databases/mmssms.db
-- ==========================================================

-- Validate SMS type values
SELECT type, COUNT(*) AS count
FROM sms
GROUP BY type
ORDER BY type;

-- Identify conversation threads and participants
SELECT
    thread_id,
    address,
    COUNT(*) AS message_count,
    MIN(datetime(date/1000,'unixepoch')) AS first_utc,
    MAX(datetime(date/1000,'unixepoch')) AS last_utc
FROM sms
GROUP BY thread_id, address
ORDER BY message_count DESC;

-- Extract SMS records with raw and UTC times
SELECT
    _id,
    thread_id,
    address,
    type,
    read,
    date AS raw_date_ms,
    datetime(date/1000,'unixepoch') AS utc_time,
    body
FROM sms
ORDER BY date;

-- Compare date and date_sent fields
SELECT
    _id,
    address,
    type,
    date,
    date_sent,
    datetime(date/1000,'unixepoch') AS date_utc,
    CASE
        WHEN date_sent > 0
        THEN datetime(date_sent/1000,'unixepoch')
        ELSE NULL
    END AS date_sent_utc
FROM sms
ORDER BY date;
